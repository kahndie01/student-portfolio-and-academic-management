// =====================================================
// contact.js — contact form validation
// Demonstrates: event handling, form validation, DOM manipulation
// =====================================================

(function () {
  const form = document.getElementById("contactForm");
  if (!form) return;

  const formStatus = document.getElementById("formStatus");

  const fields = {
    name: document.getElementById("name"),
    email: document.getElementById("email"),
    phone: document.getElementById("phone"),
    message: document.getElementById("message"),
  };

  function setInvalid(fieldName, isInvalid) {
    const group = document.getElementById("group-" + fieldName);
    if (group) group.classList.toggle("invalid", isInvalid);
  }

  function validateName() {
    const value = fields.name.value.trim();
    const valid = value.length > 0;
    setInvalid("name", !valid);
    return valid;
  }

  function validateEmail() {
    const value = fields.email.value.trim();
    // basic, reliable email pattern: text@text.text
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const valid = value.length > 0 && emailPattern.test(value);
    setInvalid("email", !valid);
    return valid;
  }

  function validatePhone() {
    const value = fields.phone.value.trim();
    // digits only (optionally allow a leading +), no letters or symbols
    const digitsOnlyPattern = /^\+?[0-9]{7,15}$/;
    const valid = value.length > 0 && digitsOnlyPattern.test(value);
    setInvalid("phone", !valid);
    return valid;
  }

  function validateMessage() {
    const value = fields.message.value.trim();
    const valid = value.length > 0;
    setInvalid("message", !valid);
    return valid;
  }

  // live validation as the user types/leaves a field
  fields.name.addEventListener("blur", validateName);
  fields.email.addEventListener("blur", validateEmail);
  fields.phone.addEventListener("blur", validatePhone);
  fields.message.addEventListener("blur", validateMessage);

  // prevent non-digit characters from even being typed in the phone field
  fields.phone.addEventListener("input", () => {
    fields.phone.value = fields.phone.value.replace(/[^0-9+]/g, "");
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    formStatus.classList.remove("show");

    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isPhoneValid = validatePhone();
    const isMessageValid = validateMessage();

    const allValid = isNameValid && isEmailValid && isPhoneValid && isMessageValid;

    if (!allValid) {
      const firstInvalid = form.querySelector(".invalid input, .invalid textarea");
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    // Simulated submit (no backend attached) — replace with a real
    // endpoint or service (e.g. Formspree, EmailJS) when deploying.
    formStatus.textContent = `Thank you, ${fields.name.value.trim()}! Your message has been received — Esther will get back to you shortly.`;
    formStatus.classList.add("show");
    form.reset();
    Object.keys(fields).forEach((key) => setInvalid(key, false));
  });
})();
