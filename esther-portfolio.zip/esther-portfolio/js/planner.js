// =====================================================
// planner.js — Academic Planner task management system
// Demonstrates: arrays, functions, DOM manipulation,
// event handling, dynamic content updates, localStorage
// =====================================================

(function () {
  const STORAGE_KEY = "esther-academic-planner-tasks";

  const taskForm = document.getElementById("taskForm");
  const taskInput = document.getElementById("taskInput");
  const taskDate = document.getElementById("taskDate");
  const taskPriority = document.getElementById("taskPriority");
  const taskListEl = document.getElementById("task-list");
  const statTotal = document.getElementById("statTotal");
  const statPending = document.getElementById("statPending");
  const statDone = document.getElementById("statDone");
  const filterButtons = document.querySelectorAll(".filter-btn");

  if (!taskForm) return; // not on planner page

  // ---- Starter data (array of task objects) ----
  const starterTasks = [
    { id: crypto.randomUUID(), text: "Read Chapter 3 — Data Structures", date: "", priority: "medium", done: true },
    { id: crypto.randomUUID(), text: "Finish HTML/CSS assignment", date: "", priority: "high", done: false },
    { id: crypto.randomUUID(), text: "Submit COS106 term project", date: "", priority: "high", done: false },
    { id: crypto.randomUUID(), text: "Group study — Calculus revision", date: "", priority: "low", done: false },
  ];

  let tasks = loadTasks();
  let currentFilter = "all";

  function loadTasks() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : starterTasks;
    } catch (err) {
      console.error("Could not read saved tasks:", err);
      return starterTasks;
    }
  }

  function saveTasks() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (err) {
      console.error("Could not save tasks:", err);
    }
  }

  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function formatDate(dateStr) {
    if (!dateStr) return "";
    const d = new Date(dateStr + "T00:00:00");
    if (isNaN(d)) return "";
    return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  }

  function isOverdue(dateStr, done) {
    if (!dateStr || done) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dateStr + "T00:00:00");
    return due < today;
  }

  function getFilteredTasks() {
    if (currentFilter === "pending") return tasks.filter((t) => !t.done);
    if (currentFilter === "done") return tasks.filter((t) => t.done);
    return tasks;
  }

  // ---- Render ----
  function render() {
    const visible = getFilteredTasks();
    taskListEl.innerHTML = "";

    if (visible.length === 0) {
      taskListEl.innerHTML = `
        <li class="empty-state">
          <span class="eyebrow">Nothing here</span>
          <p>${currentFilter === "done" ? "No completed tasks yet." : "No tasks to show — add one above."}</p>
        </li>`;
    } else {
      visible.forEach((task) => {
        const li = document.createElement("li");
        li.className = "task-item" + (task.done ? " done" : "");
        li.dataset.id = task.id;

        const overdue = isOverdue(task.date, task.done);
        const dateLabel = formatDate(task.date);

        li.innerHTML = `
          <button class="task-check" aria-label="Toggle task complete">
            <svg viewBox="0 0 16 16" fill="none"><path d="M2 8.5L6 12L14 3.5" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <div class="task-main">
            <div class="task-title">${escapeHTML(task.text)}</div>
            <div class="task-meta">
              <span class="tag ${task.priority === "high" ? "gold" : task.priority === "medium" ? "teal" : ""}">${task.priority} priority</span>
              ${dateLabel ? `<span class="task-due ${overdue ? "overdue" : ""}">${overdue ? "Overdue: " : "Due "}${dateLabel}</span>` : ""}
            </div>
          </div>
          <button class="task-delete" aria-label="Delete task">✕</button>
        `;

        taskListEl.appendChild(li);
      });
    }

    updateStats();
  }

  function updateStats() {
    statTotal.textContent = tasks.length;
    statPending.textContent = tasks.filter((t) => !t.done).length;
    statDone.textContent = tasks.filter((t) => t.done).length;
  }

  // ---- Event handling ----
  taskForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = taskInput.value.trim();
    if (!text) return;

    tasks.unshift({
      id: crypto.randomUUID(),
      text,
      date: taskDate.value,
      priority: taskPriority.value,
      done: false,
    });

    saveTasks();
    render();
    taskForm.reset();
    taskInput.focus();
  });

  taskListEl.addEventListener("click", (e) => {
    const li = e.target.closest(".task-item");
    if (!li) return;
    const id = li.dataset.id;

    if (e.target.closest(".task-check")) {
      const task = tasks.find((t) => t.id === id);
      if (task) task.done = !task.done;
      saveTasks();
      render();
    }

    if (e.target.closest(".task-delete")) {
      tasks = tasks.filter((t) => t.id !== id);
      saveTasks();
      render();
    }
  });

  filterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const filter = btn.dataset.filter;

      if (filter === "clear") {
        tasks = tasks.filter((t) => !t.done);
        saveTasks();
        render();
        return;
      }

      currentFilter = filter;
      filterButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      render();
    });
  });

  render();
})();
