// =====================================================
// main.js — shared behaviour across every page
// (mobile navigation + skill bar animation on About page)
// =====================================================

document.addEventListener("DOMContentLoaded", () => {

  // ---- Mobile nav toggle ----
  const navToggle = document.getElementById("navToggle");
  const navLinks = document.getElementById("navLinks");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      navToggle.classList.toggle("open", isOpen);
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    // Close the menu automatically once a link is chosen (mobile UX)
    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("open");
        navToggle.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  // ---- Animate skill bars into view (About page) ----
  const skillBars = document.querySelectorAll(".skill-bar-fill");
  if (skillBars.length) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const bar = entry.target;
            const percent = bar.getAttribute("data-fill") || "0";
            bar.style.width = percent + "%";
            observer.unobserve(bar);
          }
        });
      },
      { threshold: 0.4 }
    );
    skillBars.forEach((bar) => observer.observe(bar));
  }

});
