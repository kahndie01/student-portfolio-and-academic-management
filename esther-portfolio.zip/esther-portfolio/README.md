# Esther Sugh — Academic Portfolio

A 5-page responsive student portfolio and academic planner built with plain HTML, CSS and JavaScript (no frameworks, no build step).

## Structure
```
index.html          Homepage
about.html           About Me
projects.html        Projects
planner.html         Academic Planner (interactive)
contact.html         Contact form
css/styles.css       All styling
js/main.js           Shared nav + skill bar animation
js/planner.js        Task manager logic (add / complete / delete, saved via localStorage)
js/contact.js        Contact form validation
assets/              Photo + project screenshot graphics
```

## Before you submit / host it
1. **Projects page** — the three projects (Calculator, To-Do List, Blog Layout) are placeholders based on typical first-year work. Swap in your real projects: replace the images in `assets/` with real screenshots, and update the `href="#"` demo/source links in `projects.html` with your actual links (e.g. your live site and GitHub repo URLs).
2. **Video** — `projects.html` embeds a sample YouTube video. Replace the `src` in the `<iframe>` with your own demo video if you have one, or remove the section.
3. **Contact form** — the form validates fully in the browser but isn't wired to a real inbox yet. To actually receive messages, connect it to a free form service like **Formspree** or **EmailJS** (add their script/action per their docs) — otherwise it only shows a "sent" confirmation locally.

## Hosting it live (free options)
- **GitHub Pages**: push this folder to a GitHub repo → Settings → Pages → deploy from the `main` branch. Your link will be `https://<username>.github.io/<repo-name>/`.
- **Netlify / Vercel**: drag-and-drop this folder in their dashboard for an instant live link.

Submit both the live link and the GitHub repository link as required by the assignment brief.
